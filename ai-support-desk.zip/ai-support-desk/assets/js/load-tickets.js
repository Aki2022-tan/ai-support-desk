document.addEventListener("DOMContentLoaded", function () {
  const searchInput = document.getElementById("searchInput");
  const ticketContainer = document.getElementById("ticketContainer");
  const tabs = document.querySelectorAll(".ticket-tab");

  let page = 1;
  let loading = false;
  let tab = "ongoing";
  let search = "";

  function loadTickets(reset = false) {
    if (loading) return;
    loading = true;

    if (reset) {
      page = 1;
      ticketContainer.innerHTML = "";
    }

    const formData = new FormData();
    formData.append("page", page);
    formData.append("search", search);

    const url =
      tab === "ongoing"
        ? "ajax/fetch-ongoing-tickets.php"
        : "ajax/fetch-resolved-tickets.php";

    fetch(url, {
      method: "POST",
      body: formData,
    })
      .then((res) => res.text())
      .then((data) => {
        if (data.trim()) {
          ticketContainer.insertAdjacentHTML("beforeend", data);
          page++;
        }
        loading = false;
      })
      .catch(() => {
        console.error("Failed to load tickets.");
        loading = false;
      });
  }

  // Debounce function for search
  function debounce(fn, delay) {
    let timeout;
    return function (...args) {
      clearTimeout(timeout);
      timeout = setTimeout(() => fn.apply(this, args), delay);
    };
  }

  const debouncedSearch = debounce((e) => {
    search = e.target.value.trim();
    loadTickets(true);
  }, 300);

  searchInput.addEventListener("input", debouncedSearch);

  // Throttle for scroll
  function throttle(fn, limit) {
    let inThrottle;
    return function () {
      if (!inThrottle) {
        fn();
        inThrottle = true;
        setTimeout(() => (inThrottle = false), limit);
      }
    };
  }

  window.addEventListener(
    "scroll",
    throttle(() => {
      if (
        window.innerHeight + window.scrollY >=
        document.body.offsetHeight - 100
      ) {
        loadTickets();
      }
    }, 300)
  );

  // Tab switching
  tabs.forEach((t) => {
    t.addEventListener("click", () => {
      tabs.forEach((tab) => tab.classList.remove("active"));
      t.classList.add("active");
      tab = t.dataset.tab;
      loadTickets(true);
    });
  });

  loadTickets(true);
});