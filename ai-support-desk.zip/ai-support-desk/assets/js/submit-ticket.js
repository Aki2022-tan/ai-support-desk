const input = document.getElementById('subjectInput');
const suggestionList = document.getElementById('suggestionList');
const aiLoader = document.getElementById('aiLoader');

const localSuggestions = [
  "Login Issue",
  "Cannot reset password",
  "Payment not reflected",
  "Bug on dashboard",
  "Unable to submit ticket",
  "App crashes on open",
  "Account locked",
];

function showSuggestions(suggestions) {
  suggestionList.innerHTML = '';
  if (suggestions.length === 0) {
    suggestionList.classList.add('hidden');
    return;
  }

  suggestions.forEach(text => {
    const li = document.createElement('li');
    li.textContent = text;
    li.className = "cursor-pointer px-4 py-2 hover:bg-blue-100 transition";
    li.onclick = () => {
      input.value = text;
      suggestionList.classList.add('hidden');
    };
    suggestionList.appendChild(li);
  });

  suggestionList.classList.remove('hidden');
}

let aiDebounceTimeout;

input.addEventListener('input', () => {
  const query = input.value.trim().toLowerCase();
  clearTimeout(aiDebounceTimeout);

  if (query === '') {
    showSuggestions([]);
    aiLoader.classList.add('hidden');
    return;
  }

  const localMatches = localSuggestions.filter(s =>
    s.toLowerCase().includes(query)
  );
  showSuggestions(localMatches);

  if (query.length >= 3) {
    aiLoader.classList.remove('hidden');

    aiDebounceTimeout = setTimeout(async () => {
      try {
        const res = await fetch('../api/ai-suggest.php?q=' + encodeURIComponent(query));
        const data = await res.json();
        const aiMatches = data.suggestions || [];
        const combined = [...new Set([...localMatches, ...aiMatches])];

        showSuggestions(combined);
      } catch (err) {
        console.error('AI Suggestion Error:', err);
      } finally {
        aiLoader.classList.add('hidden');
      }
    }, 500);
  } else {
    aiLoader.classList.add('hidden');
  }
});