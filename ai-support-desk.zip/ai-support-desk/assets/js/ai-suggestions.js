let debounceTimer;
const subjectInput = document.getElementById('subjectInput');
const suggestionList = document.getElementById('suggestionList');
const loader = document.getElementById('aiLoader');

const cache = {}; // Simple in-memory cache

if (subjectInput) {
  subjectInput.addEventListener('input', () => {
    clearTimeout(debounceTimer);
    const query = subjectInput.value.trim();

    if (query.length < 3) {
      suggestionList.classList.add('hidden');
      return;
    }

    loader.classList.remove('hidden');

    debounceTimer = setTimeout(() => {
      // ✅ Check cache before API call
      if (cache[query]) {
        renderSuggestions(cache[query]);
        loader.classList.add('hidden');
        return;
      }

      // 👇 Call API if not in cache
      fetch(`../api/suggest-subject.php?q=${encodeURIComponent(query)}`)
        .then(res => res.json())
        .then(data => {
          loader.classList.add('hidden');

          // ✅ Save to cache
          cache[query] = data.suggestions;

          renderSuggestions(data.suggestions);
        })
        .catch(err => {
          console.error('AI API Error:', err);
          loader.classList.add('hidden');
          suggestionList.classList.add('hidden');
        });
    }, 600); // Delay API call
  });

  // Optional: Hide suggestion list on outside click
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.relative')) {
      suggestionList.classList.add('hidden');
    }
  });
}

// 🔁 Render function for suggestions
function renderSuggestions(suggestions) {
  suggestionList.innerHTML = '';

  if (suggestions.length === 0) {
    suggestionList.classList.add('hidden');
    return;
  }

  suggestions.forEach(text => {
    const li = document.createElement('li');
    li.textContent = text;
    li.className = "px-4 py-2 hover:bg-blue-50 cursor-pointer";
    li.addEventListener('click', () => {
      subjectInput.value = text;
      suggestionList.classList.add('hidden');
    });
    suggestionList.appendChild(li);
  });

  suggestionList.classList.remove('hidden');
}