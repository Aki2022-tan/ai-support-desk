document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('form');
  if (!form) return;

  const submitBtn = form.querySelector('button[type="submit"]');
  if (!submitBtn) return;

  const subjectInput = form.querySelector('input[name="subject"]');
  const messageInput = form.querySelector('textarea[name="message"]');

  const originalText = submitBtn.textContent;

  const badWords = [
    'sex', 'sexual', 'intercourse', 'nude', 'naked', 'horny', 'porn', 'puke',
    'kantot', 'jakol', 'bj', 'blowjob', 'tite', 'puki', 'burat', 'vagina', 'penis',
    'fuck', 'shit', 'bitch', 'asshole', 'puta', 'pokpok', 'panty', 'libog', 'masturbate'
  ];

  function containsBadWords(text) {
    const lowerText = text.toLowerCase();
    return badWords.some(word => lowerText.includes(word));
  }

  function showError(input) {
    input.classList.add('border', 'border-red-500', 'ring-1', 'ring-red-300');
  }

  function clearError(input) {
    input.classList.remove('border', 'border-red-500', 'ring-1', 'ring-red-300');
  }

  function validateLive() {
    const subjectHasBad = containsBadWords(subjectInput.value);
    const messageHasBad = containsBadWords(messageInput.value);

    if (subjectHasBad) showError(subjectInput);
    else clearError(subjectInput);

    if (messageHasBad) showError(messageInput);
    else clearError(messageInput);

    if (subjectHasBad || messageHasBad) {
      submitBtn.disabled = true;
      submitBtn.classList.add('opacity-60', 'cursor-not-allowed');
    } else {
      submitBtn.disabled = false;
      submitBtn.classList.remove('opacity-60', 'cursor-not-allowed');
    }
  }

  // Live validation while typing
  subjectInput.addEventListener('input', validateLive);
  messageInput.addEventListener('input', validateLive);

  form.addEventListener('submit', (e) => {
    const subjectHasBad = containsBadWords(subjectInput.value);
    const messageHasBad = containsBadWords(messageInput.value);

    if (subjectHasBad || messageHasBad) {
      e.preventDefault();
      alert('🚫 Your subject or message contains inappropriate words and cannot be submitted.');
      submitBtn.textContent = originalText;

      if (subjectHasBad) showError(subjectInput);
      if (messageHasBad) showError(messageInput);
      return;
    }

    // Valid: show submitting state
    submitBtn.disabled = true;
    submitBtn.textContent = '🚀 Submitting...';
    submitBtn.classList.add('opacity-60', 'cursor-not-allowed');
  });
});