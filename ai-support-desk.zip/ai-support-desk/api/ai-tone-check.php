<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';

$message = $_POST['message'] ?? '';
$ticket_id = $_POST['ticket_id'] ?? '';

if (!$message || !$ticket_id) {
  echo json_encode(['error' => 'Missing message or ticket ID']);
  exit;
}

$prompt = "What is the emotional tone of this support message? Reply with only one word: Polite, Angry, Rude, Neutral, or Frustrated.\n\nMessage:\n" . $message;

$data = [
  "model" => "command-r-plus",
  "prompt" => $prompt,
  "max_tokens" => 10
];

$ch = curl_init("https://api.cohere.ai/v1/generate");
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_POST => true,
  CURLOPT_HTTPHEADER => [
    "Authorization: Bearer $cohere_api_key",
    "Content-Type: application/json"
  ],
  CURLOPT_POSTFIELDS => json_encode($data)
]);

$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);
$tone = ucfirst(strtolower(trim($result['generations'][0]['text'] ?? '')));

// Validate tone
$allowed = ['Polite', 'Angry', 'Rude', 'Neutral', 'Frustrated'];
if (!in_array($tone, $allowed)) {
  $tone = 'Neutral'; // fallback
}

// Use `$conn` (from db.php) to update ticket
$stmt = $conn->prepare("UPDATE support_tickets SET ai_tone = :tone WHERE id = :id");
$success = $stmt->execute([
  ':tone' => $tone,
  ':id' => $ticket_id
]);

echo json_encode(['success' => $success, 'tone' => $tone]);