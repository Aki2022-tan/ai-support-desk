<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';

$message = $_POST['message'] ?? '';
$ticket_id = $_POST['ticket_id'] ?? '';

if (!$message || !$ticket_id) {
  echo json_encode(['error' => 'Missing message or ticket ID']);
  exit;
}

$prompt = <<<PROMPT
You are a multilingual language expert AI. 

1. First, detect the original language of the message. 
2. If it's a regional dialect from the Philippines (Tagalog, Cebuano, Ilocano, Bicol, Hiligaynon, Waray, etc.), label it properly.
3. If you are unsure, guess the closest major language or say "Unknown".
4. Then translate the message into **clear English** as best you can.

Reply in this exact format:
Language: <language>
Translation: <translated text>

Message:
$message
PROMPT;

$data = [
  "model" => "command-r-plus",
  "prompt" => $prompt,
  "max_tokens" => 200
];

$ch = curl_init("https://api.cohere.ai/v1/generate");
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_POST => true,
  CURLOPT_HTTPHEADER => [
    "Authorization: Bearer $cohere_api_key",
    "Content-Type: application/json"
  ],
  CURLOPT_POSTFIELDS => json_encode($data)
]);

$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);
$text = trim($result['generations'][0]['text'] ?? '');

// Parse response
$language = '';
$translated_msg = '';

if (preg_match('/Language:\s*(.+)/i', $text, $lang_match)) {
  $language = trim($lang_match[1]);
}
if (preg_match('/Translation:\s*(.+)/is', $text, $trans_match)) {
  $translated_msg = trim($trans_match[1]);
}

// ✅ Safe PDO update
$sql = "UPDATE support_tickets SET language = :language, translated_msg = :translated_msg WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([
  ':language' => $language ?: 'Unknown',
  ':translated_msg' => $translated_msg ?: 'This message could not be auto-translated. Please review manually.',
  ':id' => $ticket_id
]);

echo json_encode([
  'success' => strtolower($language) !== 'unknown' ? true : false,
  'fallback' => strtolower($language) === 'unknown' ? true : false,
  'language' => $language,
  'translated' => $translated_msg
]);
?>