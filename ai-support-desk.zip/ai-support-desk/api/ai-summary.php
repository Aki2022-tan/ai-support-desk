<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';

// Get the POST data
$message = $_POST['message'] ?? '';
$ticket_id = $_POST['ticket_id'] ?? '';

if (!$message || !$ticket_id) {
  echo json_encode(['error' => 'Missing message or ticket ID']);
  exit;
}

// Prepare the AI prompt
$prompt = "Summarize this customer support issue in one sentence:\n" . $message;

$data = [
  "model" => "command-r-plus",
  "prompt" => $prompt,
  "max_tokens" => 100
];

// Make the API request to Cohere
$ch = curl_init("https://api.cohere.ai/v1/generate");
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_POST => true,
  CURLOPT_HTTPHEADER => [
    "Authorization: Bearer $cohere_api_key",
    "Content-Type: application/json"
  ],
  CURLOPT_POSTFIELDS => json_encode($data)
]);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// Log for debugging (optional)
file_put_contents(__DIR__ . "/../summary_debug.txt", "CODE: $http_code\nRESPONSE:\n$response");

// Decode and extract summary
$result = json_decode($response, true);
$summary = trim($result['generations'][0]['text'] ?? '');

if ($summary) {
  // Use PDO from includes/db.php (which uses $conn)
  $stmt = $conn->prepare("UPDATE support_tickets SET ai_summary = ? WHERE id = ?");
  $stmt->execute([$summary, $ticket_id]);

  echo json_encode(['success' => true, 'summary' => $summary]);
} else {
  echo json_encode(['error' => 'No summary returned', 'raw' => $response]);
}
?>