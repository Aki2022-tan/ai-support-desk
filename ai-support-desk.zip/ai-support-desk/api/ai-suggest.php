<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
header('Content-Type: application/json');

$query = trim($_GET['q'] ?? '');

if ($query === '') {
  echo json_encode(['suggestions' => []]);
  exit;
}

$prompt = <<<EOT
Generate 5 short and clear customer support ticket subjects based on this query:

$query

Important: Do not suggest or generate any ticket subject that includes or implies profanity, sexual content, explicit language, hate speech, or any offensive terms — even in slang or other languages. Only include safe, appropriate, and professional topics suitable for a customer support environment.

List only the subjects, each on a new line.
EOT;

$data = [
  "model" => "command-r-plus",
  "prompt" => $prompt,
  "max_tokens" => 80,
  "temperature" => 0.7
];

$ch = curl_init("https://api.cohere.ai/v1/generate");
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_POST => true,
  CURLOPT_HTTPHEADER => [
    "Authorization: Bearer $cohere_api_key",
    "Content-Type: application/json"
  ],
  CURLOPT_POSTFIELDS => json_encode($data)
]);

$response = curl_exec($ch);
curl_close($ch);
$result = json_decode($response, true);

$text = $result['generations'][0]['text'] ?? '';
$suggestions = [];

if ($text) {
  foreach (explode("\n", $text) as $line) {
    $clean = trim(preg_replace('/^[0-9\.\-\*]+\s*/', '', $line));
    $clean = trim($clean, "\"'");
    if ($clean !== '') $suggestions[] = $clean;
  }
}

echo json_encode(['suggestions' => array_slice($suggestions, 0, 5)]);