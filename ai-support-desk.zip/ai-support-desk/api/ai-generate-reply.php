<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';

$message = $_POST['message'] ?? '';
$ticket_id = (int) ($_POST['ticket_id'] ?? 0);

if (!$message || !$ticket_id) {
  echo json_encode(['error' => 'Missing message or ticket ID']);
  exit;
}

$prompt = "You are a professional and respectful AI support assistant. Never respond with sexual, profane, violent, or inappropriate content. If the input is offensive, respond with: 'I'm unable to assist with that request.'\n\n" . $message;

$data = [
  "model" => "command-r-plus",
  "prompt" => $prompt,
  "max_tokens" => 150,
  "temperature" => 0.7
];

$ch = curl_init("https://api.cohere.ai/v1/generate");
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_POST => true,
  CURLOPT_HTTPHEADER => [
    "Authorization: Bearer $cohere_api_key",
    "Content-Type: application/json"
  ],
  CURLOPT_POSTFIELDS => json_encode($data)
]);

$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);
$reply = trim($result['generations'][0]['text'] ?? '');

if ($reply) {
  try {
    $stmt = $conn->prepare("UPDATE support_tickets SET ai_response = :reply WHERE id = :ticket_id");
    $stmt->bindParam(':reply', $reply, PDO::PARAM_STR);
    $stmt->bindParam(':ticket_id', $ticket_id, PDO::PARAM_INT);
    $stmt->execute();

    echo json_encode(['success' => true, 'reply' => $reply]);
  } catch (PDOException $e) {
    echo json_encode(['error' => 'DB Error: ' . $e->getMessage()]);
  }
} else {
  echo json_encode(['error' => 'No reply generated']);
}
?>