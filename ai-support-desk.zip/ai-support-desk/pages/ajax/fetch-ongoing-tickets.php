<?php
session_start();
require_once __DIR__ . '/../../includes/db.php';

if (!isset($_SESSION['user_id'])) {
  http_response_code(403);
  exit('Unauthorized');
}

$user_id = $_SESSION['user_id'];
$search = trim($_GET['search'] ?? '');
$page = max((int)($_GET['page'] ?? 1), 1);
$limit = 5;
$offset = ($page - 1) * $limit;

$where = "WHERE user_id = :user_id AND status NOT IN ('Resolved', 'Closed')";
$params = ['user_id' => $user_id];

if ($search !== '') {
  $where .= " AND (subject LIKE :search OR status LIKE :search)";
  $params['search'] = '%' . $search . '%';
}

$sql = "SELECT * FROM support_tickets $where ORDER BY id DESC LIMIT :limit OFFSET :offset";
$stmt = $conn->prepare($sql);

// Bind integer values separately (LIMIT and OFFSET need explicit binding)
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);

// Bind other values
foreach ($params as $key => $val) {
  $stmt->bindValue(":$key", $val);
}

$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$statusColors = [
  'Pending' => 'bg-yellow-100 text-yellow-800',
  'In Progress' => 'bg-blue-100 text-blue-800',
];

if (count($rows) === 0 && $page === 1) {
  echo $search !== ''
    ? "<p class='text-sm text-gray-500 mt-6'>🔍 No ongoing tickets found for '<strong>" . htmlspecialchars($search) . "</strong>'.</p>"
    : "<p class='text-sm text-gray-500 mt-6'>📭 You have no ongoing tickets.</p>";
  exit;
}

foreach ($rows as $row) {
  $badge = $statusColors[$row['status']] ?? 'bg-gray-100 text-gray-600';
  echo "
    <a href='ticket-detail.php?ticket_id={$row['id']}' class='block border border-gray-200 mb-4 p-4 rounded-xl hover:shadow-md hover:border-blue-200 transition-all duration-200'>
      <div class='flex justify-between items-start'>
        <div>
          <div class='font-semibold text-blue-700 text-lg'>" . htmlspecialchars($row['subject']) . "</div>
          <div class='text-sm text-gray-500'>" . date('M d, Y h:i A', strtotime($row['created_at'])) . "</div>
        </div>
        <span class='inline-block px-3 py-1 rounded-full text-xs font-semibold {$badge}'>" . htmlspecialchars($row['status']) . "</span>
      </div>";
  if (!empty($row['ai_summary'])) {
    echo "<p class='text-sm mt-2 text-gray-700'>📝 <strong>Summary:</strong> " . htmlspecialchars($row['ai_summary']) . "</p>";
  }
  if (!empty($row['admin_response'])) {
    echo "<div class='bg-green-50 border border-green-200 text-green-800 text-sm p-3 mt-2 rounded-md'>
            <strong>👨‍💼 Admin Response:</strong><br>" . nl2br(htmlspecialchars($row['admin_response'])) . "</div>";
  }
  echo "</a>";
}
?>