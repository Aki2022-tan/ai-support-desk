<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'user') {
  header("Location: ../login.php");
  exit();
}

include('../includes/config.php');
?>