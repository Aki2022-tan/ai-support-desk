<?php
// includes/db.php
require_once __DIR__ . '/config.php';

try {
    $conn = getPDOConnection(); // ← from config.php
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}