<?php
function getPDOConnection() {
    $host = 'localhost';
    $db   = 'ai_support_desk'; // ⬅️ Your actual database name
    $user = 'root';
    $pass = '';              // ⬅️ Usually blank in KSWEB
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    return new PDO($dsn, $user, $pass, $options);
}

// COHERE API KEY
$cohere_api_key = '3l6xbkbUwq2wyrbMMMeLPoDpXesAb3WQ5suCPbog';
?>